set_innertext(document.getElementById("changepwchange"),gs("Change")),set_innertext(document.getElementById("changepwclose"),gs("Close"));
//# sourceMappingURL=sourcemaps/lp_toolstrip25.js.map
