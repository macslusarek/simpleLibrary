Interfaces.TabDialogInterface=function(){var e,n;return{LPTabDialog:{openDialog:new(0,Interfaces.Definition)(Interfaces.TYPE_FUNCTION)}}}();
//# sourceMappingURL=sourcemaps/tabDialogInterface.js.map
