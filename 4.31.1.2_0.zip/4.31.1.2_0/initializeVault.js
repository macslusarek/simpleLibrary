document.addEventListener("DOMContentLoaded",function(){chrome.runtime.getBackgroundPage(function(e){window.bg=e.LPPlatform.getBackgroundInterface(),Topics.get(Topics.INITIALIZED).publish()})});
//# sourceMappingURL=sourcemaps/initializeVault.js.map
