BuildVariables={},BuildVariables.partner="",BuildVariables.getPartnerURL=function(e){return this.partner&&(e+=(e.indexOf("?")>=0?"&":"?")+"partnername="+encodeURIComponent(this.partner)),e};
//# sourceMappingURL=sourcemaps/buildVars.js.map
