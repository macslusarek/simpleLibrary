Interfaces.InfieldPopupInterface=function(){var e,n;return{lpInfield:{setArrowPosition:new(0,Interfaces.Definition)(Interfaces.TYPE_FUNCTION,{include:["contentScript"]})}}}();
//# sourceMappingURL=sourcemaps/infieldPopupInterface.js.map
