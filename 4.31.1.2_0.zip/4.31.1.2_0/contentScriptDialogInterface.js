Interfaces.ContentScriptDialogInterface=function(){var e,n;return{LPDialog:{openDialog:new(0,Interfaces.Definition)(Interfaces.TYPE_FUNCTION)}}}();
//# sourceMappingURL=sourcemaps/contentScriptDialogInterface.js.map
