sr(document,"ok","value","OK"),sr(document,"cancel","value","Cancel");
//# sourceMappingURL=sourcemaps/omnikey3.js.map
