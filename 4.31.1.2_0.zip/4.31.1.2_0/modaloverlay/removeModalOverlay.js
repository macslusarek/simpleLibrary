!function e(){var m="lpiframeoverlay",a=document.body;if(a){var o=m+"modal",r=document.getElementById(o);if(r){a.removeChild(r);var t=document.getElementsByTagName("iframe").namedItem("LPFrame");t&&t.remove()}}}();
//# sourceMappingURL=sourcemaps/modaloverlay/removeModalOverlay.js.map
