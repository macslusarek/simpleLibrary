!function(t){var n={};t.onSettingsIframeClose=function(t,o){o?n[o.tabID]=t:n=t},t.closeSettingsIframe=function(t,o){o&&"function"==typeof n[o.tabID]?n[o.tabID]():"function"==typeof n&&n()}}(this);
//# sourceMappingURL=sourcemaps/acctsiframe-background.js.map
