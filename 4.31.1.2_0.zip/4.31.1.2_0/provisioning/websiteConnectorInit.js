document.addEventListener("DOMContentLoaded",function(){document.removeEventListener("DOMContentLoaded",arguments.callee,!1),document.body.setAttribute("lastpass-extension-id","1"),document.body.setAttribute("lastpass-extension-version","1"),document.body.setAttribute("data-lp-preferences-version",1)},!1);
//# sourceMappingURL=sourcemaps/provisioning/websiteConnectorInit.js.map
